# Research package — 16 November 2026

The portfolio remains Verification Under Pressure and The Scope of Trust. Cross-document composition remains a challenger. This package contains completed novelty, methods and evidence reviews, a deterministic implementation, and independent offline auditing. It does not contain live-model findings, human expert validation, or a public preregistration.

## Start here

- [Frozen build design](research/BUILD_FREEZE.md)
- [Novelty review](research/novelty_review.md) and [source ledger](research/sources.json)
- [Methods protocol](research/methods_protocol.md)
- [Evidence review](research/evidence_review.md) and [ten candidate cases](research/candidate_cases.json)
- [Harness instructions](epistemics_lab/README.md)
- [Independent audit](research/audit_report.md)
- [Preregistration draft](research/preregistration_draft.md)
- [Human review handoff](research/human_review_protocol.md)

## Executed

Sixteen implementation tests and seven separately authored audit checks passed. Two 384-trial scripted development runs validate successes, injected acquisition/attribution failures, raw logging and analysis. The auditor independently recomputed outcomes from raw completion text. No held-out trial was run; no model API was called. Scripted responses have privileged gold access and are not model-behavior evidence.

## Changes caused by review

A uses an imported provisional snapshot, with accuracy independent of user accuracy. It does not fabricate the model's own previous answer. Evidence routes have identical first-stage prompts; the supplied route is automatic evidence rescue. This is a practical intervention, not identified psychological mediation.

B separates added scope information from formatting identical scope information. Primary attribution errors include unsupported support and unsupported refutation. Belief and direct verification are separate: a stipulated posterior can rise from .65 to .75 without making Q verified. The genuine-Q control tests general responsiveness; intervention-specific preservation of warranted trust remains untested. Core practice-to-outcome cases are analyzed separately from causal, temporal, sample and site extensions.

## Remaining work

Choose a model/endpoint and authorized resource budget, validate the provider transport, and run the real development pilot. Obtain independent domain and response review before real-document claims. Expand substantive case diversity and choose a meaningful-effect/precision target. Lock models, prompts, case sampling, estimands, exclusions and multiplicity handling before public registration and held-out testing. The current draft is not registered.

The HTTP adapter enforces a request ceiling, not a monetary spending cap. Configure credentials locally. No paid call was attempted. Disk space blocked the final handoff; with filesystem permission, only pip's regenerable HTTP download cache was cleared (about 71 MB). Installed packages and unrelated project files were not removed.
