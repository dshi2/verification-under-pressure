# Two-project research harness

Version 0.1.0, diagnostic implementation. Python 3.10+; standard library only.

**No live language-model results are included.** `validation_oracle` and `validation_biased` use scripted policies with access to hidden truth. They validate execution, logging and analysis, not scientific hypotheses. The held-out trials have not been executed. Real animal-welfare documents have not received human expert review.

## Included

- `lab.py`: deterministic case generator, real local lookup controller, six verification conditions, scripted fixtures, optional HTTP transport, strict response validation, raw logs and paired case-level analysis.
- `cases.json`: ten fictional cases distilled from the evidence specialist's candidate file. Sources and limitations are in `../research/evidence_review.md` and `candidate_cases.json`.
- `dataset.json`: seed 1729; 24 registry records × 16 conditions plus 10 welfare cases × two Q-truth strata × six arms = 504 trials. Of these, 384 are development and 120 are held out. All variants of a base case share a split.
- `tests/test_lab.py`: automated failure-mode and statistical checks.
- `validation_oracle` and `validation_biased`: manifests, raw responses and diagnostic summaries. Each contains 384 development trials.
- `../research/audit_report.md`: separate review, independent raw-response recomputation and remaining limitations.

## Run locally

From this directory:

```sh
python3 -m unittest discover -s tests -v
python3 lab.py generate --output new_dataset.json --seed 1729 --n-a 24
python3 lab.py run --dataset new_dataset.json --output my_oracle_run --adapter oracle
python3 lab.py analyze my_oracle_run --output my_oracle_run/analysis.json
```

Output paths must be new: the harness refuses to overwrite an existing run. A run writes the full schedule before execution and flushes each completed trial. Interrupted trials remain in the analysis denominator as `not_completed`. Do not splice results from different runs or silently replace failures.

## Experimental meaning

**A — Verification Under Pressure.** Snapshot accuracy and assertion accuracy are independently balanced. There is no fabricated model first answer: the snapshot is imported and provisional. The first model prompt is identical across evidence routes. The controller subsequently rescues one randomized route by supplying evidence even after a skip. The optional route supplies evidence only on a valid lookup request. Primary acquisition is successful relevant-record retrieval; attempts are reported separately. Both routes give two response opportunities. This identifies an automatic-evidence-rescue effect under the tested workflow, not a complete mediation model or spontaneous concession from a self-generated answer.

The JSON acquisition response invokes an actual deterministic Python lookup. Its record is delivered via a controller message. This is not a test of native tool-message authority. The registry task is intentionally simple and repetitive; 24 IDs are not 24 independent task families. Cluster intervals concern sampled records under these prompts, not general task diversity.

**B — Scope of Trust.** Primary error is direct attribution of support OR refutation to unchecked Q. Unsupported support and refutation are also separate secondary outcomes. Truth and verification are distinct. Genuine Q checks can support or refute the same underlying Q. The six arms are content-only, narrow-P, unrelated-R, scoped prose, scoped fields, and Q-verified.

Scoped prose and fields use identical clauses in the same order. The fields version is a JSON array: conclusions concern this rendering only, not typed provenance infrastructure. Narrow-to-scoped tests added clarification; prose-to-fields tests rendering. A larger narrow than unrelated effect is relevance-sensitive evidence, not a uniquely identified psychological mechanism. The outcome control checks generic responsiveness to decisive Q evidence; preserving responsiveness AFTER scope intervention remains untested.

A separate probability response is scored against an explicitly fictional source model. Baseline and unrelated-check targets are .65, narrow and scoped targets .75, and direct Q checks 0 or 1. These are conditional Bayesian targets, not empirical welfare probabilities. Truth-balanced curated worlds must not be used for population-calibration claims. The common system instruction explicitly distinguishes direct checking from relevance, so this diagnostic measures behavior with that distinction explained. A null here does not establish robustness under ordinary unconstrained writing.

Core practice/documentation-to-outcome cases B01–B04 are analyzed separately from causal, temporal, sample and site extensions. Only three core cases are in development; this is software validation, not adequate confirmatory domain coverage.

The natural-language rationale is retained but not automatically adjudicated. A correct categorical label with a contradictory rationale remains a human-review issue. The prototype does not establish free-form endorsement rates.

## Optional live transport — not executed

The adapter accepts a Chat Completions-compatible endpoint and an explicit model. It sends only fictional prompts. It does not select or discover an endpoint, read a credential file, or spend by default. Credentials are read from a named environment variable and never included in request logs. Set credentials locally; do not put keys in command-line arguments or endpoint URLs.

```sh
python3 lab.py run --dataset dataset.json --output model_dev_run \
  --adapter http --endpoint "$RESEARCH_ENDPOINT" --model "$RESEARCH_MODEL" \
  --key-env RESEARCH_API_KEY --max-calls 672 --max-tokens 512
```

This full development batch requires at most 672 completion requests (288 A trials with two stages and 96 B trials with one). `--max-calls` is a request ceiling, **not a monetary budget**. Select the provider/model and a spending cap before a paid run; enforce the cap at the provider if needed. Set the request ceiling for the authorized batch. No automatic retries occur. Reaching the ceiling logs remaining trials as errors without sending further requests.

Default token parameter is `max_completion_tokens`; use `--token-field max_tokens` only for endpoints that require that compatibility field. Temperature is omitted by default, because supported parameters vary; `--temperature` explicitly sets it. Repeat responses are not assumed statistically independent merely because their trial IDs differ. Provider response metadata, usage and finish reasons are logged when returned. Truncations/invalid JSON remain invalid responses; no covert repair call occurs. This transport is covered by mocked HTTP tests but has not been validated against a live provider.

The command-line runner runs development trials only. Before exposing a held-out runner, finish the preregistration draft, meaningful-effect threshold, model sampling plan, case review, and sample-size/precision decision. A local build freeze is not a public preregistration.

## Analysis limits

Primary differences are paired within base cases. Repeated truth strata and trials are averaged within case before bootstrap resampling. Complete-cluster exploratory intervals accompany all-scheduled missing-outcome bounds. Missing responses are not converted to correct answers or silent skips. This pilot analyzer produces estimates and exploratory intervals, not confirmatory significance declarations or multiple-testing-adjusted inference. Do not interpret successful injected-effect recovery as power for a real unknown effect.

See `../research/preregistration_draft.md` for the uncompleted decisions required before a confirmatory study.
