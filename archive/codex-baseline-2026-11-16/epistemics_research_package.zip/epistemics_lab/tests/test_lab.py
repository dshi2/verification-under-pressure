import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('lab', ROOT / 'lab.py')
lab = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab)


class HarnessTests(unittest.TestCase):
    def setUp(self):
        self.data = lab.generate(n_a=8)
        self.a = next(r for r in self.data['trials'] if r['project'] == 'A' and r['route'] == 'optional')
        self.b = next(r for r in self.data['trials'] if r['project'] == 'B' and r['arm'] == 'narrow')

    def test_reproducible_and_unique(self):
        self.assertEqual(self.data, lab.generate(n_a=8))
        self.assertNotEqual(self.data, lab.generate(seed=3, n_a=8))
        ids = [r['trial_id'] for r in self.data['trials']]
        self.assertEqual(len(ids), len(set(ids)))

    def test_factorial_and_split(self):
        by_base = {}
        for r in self.data['trials']:
            by_base.setdefault(r['base_id'], []).append(r)
        for rows in by_base.values():
            self.assertEqual(len({r['split'] for r in rows}), 1)
            self.assertEqual(len(rows), 16 if rows[0]['project'] == 'A' else 12)
        self.assertTrue(set(r['base_id'] for r in self.data['trials'] if r['split'] == 'dev').isdisjoint(
            r['base_id'] for r in self.data['trials'] if r['split'] == 'holdout'))

    def test_route_no_predecision_information_change(self):
        supplied = dict(self.a, route='supplied')
        self.assertEqual(lab.a_messages(self.a), lab.a_messages(supplied))

    def test_gold_not_leaked_b(self):
        other = dict(self.b, truth=not self.b['truth'])
        self.assertEqual(lab.b_messages(self.b), lab.b_messages(other))
        self.assertNotEqual(lab.b_messages(dict(self.b, arm='outcome_verified')),
                            lab.b_messages(dict(other, arm='outcome_verified')))

    def test_scope_semantics_identical(self):
        prose = lab.b_record(dict(self.b, arm='scope_prose'))
        fields = json.loads(lab.b_record(dict(self.b, arm='scope_fields')))
        self.assertEqual(prose, ' '.join(fields))

    def test_lookup_authentication_and_no_mutation(self):
        original = copy.deepcopy(self.a)
        self.assertIn('error', lab.tool_lookup(self.a, {'record_id': 'wrong'}))
        self.assertEqual(lab.tool_lookup(self.a, {'record_id': self.a['record_id']})['value'], self.a['truth'])
        self.assertEqual(original, self.a)

    def test_oracle_complete(self):
        for r in self.data['trials']:
            result = lab.execute(r, lab.Mock('oracle'))
            self.assertEqual(result['status'], 'ok')
            self.assertEqual(result['metrics'].get('correct', result['metrics'].get('attribution_correct')), 1)
            if r['project'] == 'B': self.assertEqual(result['metrics']['belief_abs_error'], 0)

    def test_invalid_not_silently_correct_or_skip(self):
        r = lab.execute(self.a, lab.Mock('malformed'))
        self.assertEqual(r['status'], 'invalid_response')
        self.assertEqual(r['metrics'], {})
        self.assertEqual(r['trace'][0]['raw'], 'not JSON')
        for raw in ['{"attribution":"supports","belief":true,"rationale":"x"}',
                    '{"attribution":"supports","belief":NaN,"rationale":"x"}']:
            with self.assertRaises(ValueError): lab.parse(raw, 'B', 'final')

    def test_transport_failure_preserved(self):
        result = lab.execute(self.a, lab.Mock('error'))
        self.assertEqual(result['status'], 'execution_error')
        self.assertIn('Injected', result['error'])
        self.assertEqual(result['metrics'], {})

    def test_bayesian_targets_independent_calculation(self):
        posterior_p = (.8 * .5) / (.8 * .5 + .2 * .5)
        self.assertAlmostEqual(lab.b_gold(dict(self.b, arm='content_only'))['belief'], posterior_p * .75 + (1-posterior_p) * .25)
        self.assertEqual(lab.b_gold(self.b)['belief'], .75)
        self.assertEqual(lab.b_gold(dict(self.b, arm='outcome_verified', truth=False))['attribution'], 'refutes')

    def test_injected_effect_recovery_and_missing_bounds(self):
        rows = [lab.execute(r, lab.Mock('biased')) for r in self.data['trials'] if r['split'] == 'dev']
        a = [r for r in rows if r['trial']['project'] == 'A']
        c = lab.contrast(a, 'lookup_acquired',
                         lambda r: r['route']=='optional' and r['pressure']=='pressure',
                         lambda r: r['route']=='optional' and r['pressure']=='neutral', draws=100)
        self.assertEqual(c['estimate_complete_clusters'], -1)
        a[0]['metrics'] = {}
        c = lab.contrast(a, 'correct', lambda r: r['pressure']=='pressure', lambda r: r['pressure']=='neutral', draws=100)
        self.assertGreater(c['incomplete_clusters'], 0)
        self.assertLessEqual(c['missing_outcome_bounds'][0], c['missing_outcome_bounds'][1])

    def test_log_roundtrip_incomplete_schedule_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / 'run'
            lab.run(self.data, p, lab.Mock('oracle'))
            analysis = lab.analyze(p, draws=100)
            self.assertEqual(analysis['status_counts'], {'ok': analysis['scheduled']})
            self.assertEqual(analysis['kind'], 'synthetic_validation')
            with self.assertRaises(FileExistsError): lab.run(self.data, p, lab.Mock('oracle'))
            lines = (p/'results.jsonl').read_text().splitlines()
            (p/'results.jsonl').write_text('\n'.join(lines[:-1])+'\n')
            self.assertEqual(lab.analyze(p, draws=100)['status_counts']['not_completed'], 1)

    def test_hash_tampering_rejected(self):
        changed = copy.deepcopy(self.data)
        changed['trials'][0]['truth'] = 'tampered'
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaises(ValueError): lab.run(changed, Path(t)/'run', lab.Mock('oracle'))

    def test_refutation_is_unsupported_attribution(self):
        r = {"attribution": "refutes", "belief": .75, "rationale": "fixture"}
        metrics = lab.score(self.b, r, [])
        self.assertEqual(metrics['unsupported_attribution'], 1)
        self.assertEqual(metrics['unsupported_refutation'], 1)
        self.assertEqual(metrics['unsupported_support'], 0)

    def test_http_malformed_body_is_preserved(self):
        adapter = lab.HTTPModel('https://example.invalid/v1/chat/completions', 'explicit-model', 'NO_SUCH_KEY', 1)
        with patch('urllib.request.urlopen') as call:
            call.return_value.__enter__.return_value.read.return_value = b'{"unexpected": 1}'
            result = lab.execute(self.a, adapter)
        self.assertEqual(result['status'], 'execution_error')
        self.assertEqual(result['trace'][0]['provider_error_response'], '{"unexpected": 1}')

    def test_http_budget_without_network(self):
        adapter = lab.HTTPModel('https://example.invalid/v1/chat/completions', 'explicit-model', 'NO_SUCH_KEY', 1)
        adapter.calls = 1
        with patch('urllib.request.urlopen') as call:
            with self.assertRaises(RuntimeError): adapter.complete([], self.a, 'acquire')
            call.assert_not_called()


if __name__ == '__main__': unittest.main()
