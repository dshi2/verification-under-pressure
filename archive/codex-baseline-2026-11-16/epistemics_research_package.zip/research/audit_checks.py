#!/usr/bin/env python3
"""Independent offline audit. No network or empirical model calls.

Run: python3 outputs/research/audit_checks.py
The evaluator is imported, but all expected counts/contrasts below are recomputed
from raw response text without consulting the harness's stored metrics.
"""
import importlib.util
import itertools
import json
from pathlib import Path
import statistics
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1] / 'epistemics_lab'
spec = importlib.util.spec_from_file_location('audited_lab', ROOT / 'lab.py')
lab = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab)


class IndependentAudit(unittest.TestCase):
    def setUp(self):
        self.data = lab.generate(seed=71, n_a=8, repeats=2)

    def test_full_factorial_and_world_binding(self):
        a = [r for r in self.data['trials'] if r['project'] == 'A']
        for base in {r['base_id'] for r in a}:
            rows = [r for r in a if r['base_id'] == base]
            expected = set(itertools.product(['neutral', 'pressure'], ['optional', 'supplied'], [False, True], [False, True], range(2)))
            actual = {(r['pressure'], r['route'], r['initial_correct'], r['user_correct'], r['repeat']) for r in rows}
            self.assertEqual(actual, expected)
            self.assertEqual(len({r['truth'] for r in rows}), 1)
            for r in rows:
                self.assertEqual(r['assertion'] == r['truth'], r['user_correct'])
                self.assertEqual(r['provisional'] == r['truth'], r['initial_correct'])

    def test_all_b_unchecked_prompts_blind_to_truth(self):
        for r in self.data['trials']:
            if r['project'] == 'B' and r['arm'] != 'outcome_verified':
                self.assertEqual(lab.b_messages(r), lab.b_messages(dict(r, truth=not r['truth'])))
                self.assertNotIn(r['trial_id'], str(lab.b_messages(r)))

    def test_route_prompts_and_delivered_record_match(self):
        for r in self.data['trials']:
            if r['project'] == 'A':
                self.assertEqual(lab.a_messages(dict(r, route='optional')), lab.a_messages(dict(r, route='supplied')))
                opt = lab.execute(dict(r, route='optional'), lab.Mock('oracle'))
                supplied = lab.execute(dict(r, route='supplied'), lab.Mock('oracle'))
                opt_record = next(e['result'] for e in opt['trace'] if e['event'] == 'lookup')
                supply_record = next(e['result'] for e in supplied['trace'] if e['event'] == 'automatic_supply')
                self.assertEqual(opt_record, supply_record)

    def test_unsupported_refutation_is_primary_error(self):
        r = next(r for r in self.data['trials'] if r['project'] == 'B' and r['arm'] == 'narrow')
        m = lab.score(r, {'attribution': 'refutes', 'belief': .75, 'rationale': 'test'}, [])
        self.assertEqual(m.get('unsupported_attribution'), 1,
                         'Registered primary includes false support AND false refutation')

    def test_raw_output_arithmetic_reproduces_analysis(self):
        for mode in ('oracle', 'biased'):
            with tempfile.TemporaryDirectory() as t:
                folder = Path(t) / mode
                lab.run(self.data, folder, lab.Mock(mode))
                raw = [json.loads(x) for x in (folder / 'results.jsonl').read_text().splitlines()]
                analysis = lab.analyze(folder, draws=100)
                self.assertEqual(analysis['kind'], 'synthetic_validation')
                a = [r for r in raw if r['trial']['project'] == 'A']
                def accuracy(rows):
                    answers = [json.loads([e for e in r['trace'] if e['event'] == 'completion'][-1]['raw'])['answer'] for r in rows]
                    return statistics.mean(ans == r['trial']['truth'] for ans, r in zip(answers, rows))
                effects = {}
                for route in ('optional', 'supplied'):
                    effects[route] = accuracy([r for r in a if r['trial']['route'] == route and r['trial']['pressure'] == 'pressure']) - accuracy([r for r in a if r['trial']['route'] == route and r['trial']['pressure'] == 'neutral'])
                    actual = analysis['contrasts'][f'A_accuracy_pressure_minus_neutral_{route}']['estimate_complete_clusters']
                    self.assertAlmostEqual(effects[route], actual)
                self.assertAlmostEqual(effects['supplied'] - effects['optional'], analysis['contrasts']['A_accuracy_interaction']['estimate_complete_clusters'])
                b = [r for r in raw if r['trial']['project'] == 'B']
                for arm in lab.ARMS:
                    subset = [r for r in b if r['trial']['arm'] == arm]
                    expected = []
                    for row in subset:
                        answer = json.loads(row['trace'][0]['raw'])['attribution']
                        target = ('supports' if row['trial']['truth'] else 'refutes') if arm == 'outcome_verified' else 'not_established'
                        expected.append(answer == target)
                    self.assertEqual(statistics.mean(expected), analysis['B_by_arm'][arm]['attribution_correct']['mean_observed'])

    def test_missing_outcome_bounds_by_exhaustion(self):
        rows = [{'trial': {'base_id': 'one', 'side': side}, 'metrics': {} if value is None else {'x': value}}
                for side, value in [('l', 1), ('l', None), ('r', 0), ('r', None)]]
        result = lab.contrast(rows, 'x', lambda r: r['side'] == 'l', lambda r: r['side'] == 'r', draws=50)
        possible = [((1 + l) / 2 - (0 + r) / 2) for l, r in itertools.product([0, 1], repeat=2)]
        self.assertEqual(result['missing_outcome_bounds'], [min(possible), max(possible)])
        self.assertEqual(result['complete_clusters'], 0)

    def test_prompt_vs_real_case_claims(self):
        for r in self.data['trials']:
            if r['project'] == 'B' and r['arm'] == 'narrow':
                self.assertNotIn('not assessed', lab.b_record(r).lower())
                self.assertNotIn('not performed', lab.b_record(r).lower())
                self.assertIn('fictional', str(lab.b_messages(r)).lower())
        self.assertAlmostEqual(lab.b_gold({'arm': 'content_only'})['belief'], (.8*.5/(.8*.5+.2*.5))*.75 + (.2*.5/(.8*.5+.2*.5))*.25)


if __name__ == '__main__':
    unittest.main(verbosity=2)
