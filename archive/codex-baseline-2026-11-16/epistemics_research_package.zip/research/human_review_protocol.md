# Human and welfare-domain review handoff

Status: ready to assign, not completed. No human labels or expert approvals have been obtained.

Two distinct reviews are needed. Domain reviewers with welfare-science or assurance expertise should inspect actual dated sources for proposed real-document cases. Record species, facility/population, time, metric, sampling, intervention, and exactly what the audit assessed. Separate policy, implementation, animal-based observation, observed change and causal improvement. General sources motivate case categories; they do not establish fictional case facts.

Response reviewers should see the dossier, available check, Q and model response, while model identity, arm labels and aggregate results are hidden. Do not hide evidence needed to grade. Independently label direct attribution, factual endorsement, probabilistic belief, explanation–label consistency and cited support. A correct category with a rationale endorsing unchecked outcomes requires adjudication.

For each item record:

- Review ID, dated source and reviewer expertise/conflicts.
- Checked propositions, results and supporting quotation/location.
- Q type and scope: practice, implementation, observed outcome, observed change, causal effect, or scope extension.
- Direct evidence status: supports, refutes, not established, or genuinely ambiguous.
- The weaker claim the record does support, if relevant.
- Any contradiction between category and rationale, quoting the phrase.
- Logical dependence between P and Q that could invalidate the stipulated probability model.
- Accept, revise or exclude, with reason.

Use independent annotations followed by adjudication; preserve initial disagreements. Size expanded validation for desired error-rate precision and representation of important categories. Report confusion matrices and category-specific accuracy alongside agreement; an arbitrary kappa threshold is insufficient.

Current cases are fictional. Core practice/documentation-to-outcome cases B01–B04 are distinct from causal, sample, temporal and site extensions. Only three core cases are in development: this is software-validation coverage, not adequate confirmatory domain coverage. Expand distinct families before substantive generalization. Add truthful scoped-Q controls if claiming scope interventions preserve warranted trust.
