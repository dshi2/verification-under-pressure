# Preregistration draft — NOT REGISTERED

Status: **all current runs are exploratory diagnostics or synthetic harness validation**. This draft is incomplete. A build freeze is not a confirmatory analysis freeze. Complete the open fields, lock the full item/prompt/analysis manifest, and timestamp the final protocol before any held-out confirmatory run. Do not relabel already inspected results as confirmatory.

## Fixed questions and design

Project A asks whether insistence changes successful acquisition of decisive evidence and whether concealed automatic evidence rescue changes its effect on final accuracy. The 16-cell matched design crosses neutral/pressure, optional/supplied evidence, correct/incorrect imported provisional snapshot, and correct/incorrect user assertion. Stage-1 instructions are identical and route assignment is concealed. The same current record is returned by a successful optional lookup or by automatic rescue. Imported records are not self-generated prior model answers. Psychological mediation is not identified.

Project B asks whether authentic verification of P produces unsupported direct attribution about distinct outcome Q, and whether explicit scope or its rendering changes that error. Its six arms are `content_only`, `narrow`, `unrelated`, `scope_prose`, `scope_fields`, and `outcome_verified`. World truth stays fixed within each case. The first five arms do not directly establish Q; the last reveals whether Q is true or false. Unsupported attribution includes **either supports or refutes** in an unchecked arm. Belief in Q and direct verification of Q are separate endpoints. The existing outcome control does not establish that scope clarification preserves warranted trust; scoped-Q controls would require an amended design.

## Confirmatory estimands proposed for locking

1. A: pressure-minus-neutral successful relevant lookup acquisition, optional route only. Attempted requests are secondary; wrong IDs are failures, not acquisition.
2. A: `(pressure − neutral accuracy)_supplied − (pressure − neutral accuracy)_optional`.
3. B: unsupported-attribution rate, `narrow − content_only`.
4. B: unsupported-attribution rate, `scope_prose − narrow`; negative means mitigation.

Other route differences, assertion/snapshot strata, unsupported-support/refutation directions, unrelated-verification comparison, prose/fields comparison, and belief deviations are secondary or exploratory unless explicitly promoted before the main run. A joint confirmatory report should prespecify one multiplicity family for these four main contrasts. Proposed procedure: Holm at familywise alpha 0.05, alongside absolute paired estimates and clearly labeled uncertainty. The current diagnostic analysis supplies exploratory intervals, not confirmatory tests or simultaneous intervals. A confirmatory testing implementation must be independently checked before use.

## Open fields — decisions required before confirmation

| Field | Required decision or evidence |
|---|---|
| Selected models and endpoints | **OPEN:** exact provider/local endpoint, model identifier/version, decoding settings, endpoint capabilities, and rationale for the chosen model population. Never store credentials in the manifest. |
| Resources | **OPEN:** authorized spend or local compute allocation, maximum calls/tokens, and a technical-failure retry policy. Budget exhaustion must be reported, not hidden by selective completion. |
| Item population | **OPEN:** independent base-case/source/template families, eligibility criteria, planned counts, and scope of generalization. Existing fictional case families are diagnostic fixtures, not a representative animal-welfare sample. |
| Held-out separation | **OPEN:** immutable source-family split and manifest hashes. Record what development data were inspected. No prompt or label tuning on the held-out set. |
| Minimum meaningful effects | **OPEN:** a justified absolute risk-difference threshold for each primary contrast, selected from practical/scientific significance before seeing held-out outcomes. Do not invent a threshold to match pilot estimates or budget. |
| Sample size and precision | **OPEN:** clustered variance/covariance estimates from development data, simulation assumptions, desired precision or power at the meaningful effects, and the resulting number of independent cases. Tokens, turns, and seeds are not independent sample size. Account for paired arms, family clustering, model configurations, and missingness. |
| Model repetitions and wording | **OPEN:** prespecified repetitions and wording variants, sampled independently without treating repeats as new cases. |
| Label audit | **OPEN:** blinded independent review sample and disagreement/adjudication procedure. Formal synthetic scope labels require mechanical checks. Real animal-welfare documents require human/domain-expert assessment before real-world claims or confirmatory inclusion. Agent consensus is not domain validation. |
| Statistical implementation | **OPEN:** independently verified clustered estimation, missing-outcome bounds, and any confirmatory tests/multiplicity adjustment. If source families are too few, narrow the inference instead of reporting spurious broad precision. |
| Release | **OPEN:** frozen code/data/prompt hashes, date, registry or externally timestamped protocol location, permissible raw-log release, and deviation reporting policy. |

## Pilot decisions and stopping rules

- The pilot checks comprehension, truth leakage, tool reachability, intended label semantics, outcome-control sensitivity, and differential technical failure. Fix demonstrated defects with versioned changes and revalidate development data.
- Near-universal correct checking or near-zero spillover is not a defect. Retain clean nulls, estimate their precision, and do not obscure tools, increase costs, select failure-prone items, or strengthen pressure merely to produce an effect. A scientifically motivated cost/relevance extension must become a separately declared factor or study.
- Redesign if labels are genuinely ambiguous, instructions contaminate the intended manipulation, failures make the estimand uninterpretable, or adequate precision cannot be attained for the declared population. Record the reason before a new run.
- After confirmatory lock, do not stop because an effect becomes significant or a preferred narrative appears. Stop at the prespecified complete sample or an explicitly declared technical/resource boundary; disclose incompleteness and missing-case bounds.
- Keep malformed responses, missing trials, tool errors, and retries in the log and scheduled denominators. Report valid-answer coverage and conditional performance separately. Missingness is not correctness or harmless abstention.

## Conclusions allowed

Successful completion can support bounded claims about observed acquisition, final accuracy, or direct verification attribution in the specified task/model population. It cannot prove a unique internal mechanism, establish population calibration from curated fictional cases, or show preserved warranted trust under an untested scoped-Q intervention. Synthetic policy outputs establish software behavior only. Real model findings begin only when actual endpoint responses have been collected and independently audited.
