# Our two projects — current revision 2

**1. Verification Under Pressure (Track 1).** Does social pressure change whether an AI fetches objective evidence, uses it, or both? Compare neutral, insistent and irrelevant-authority assertions; no-tool, optional-tool and supplied-evidence workflows; and right versus wrong users.

**2. The Scope of Trust (Track 2).** Does verifying a narrow animal-welfare practice make an AI wrongly attribute verification to an unchecked outcome? Nine dossier conditions distinguish matching facts, scope clarification, format, unrelated checks, another facility's check, genuine outcome evidence and a vague label.

**Backup only:** cross-document evidence composition. No third project is being built. Citation Drift, original Missing Denominator and Signed but Wrong are not active projects.

## Review the current work

- [Authoritative revision 2 protocol](research/PROTOCOLS_v1_revision2.md)
- [All 19 provisions: difference table and test mapping](research/reconciliation_v2.md)
- [Independent revision-2 audit](research/audit_report_v2.md)
- [Verified P2 source access](research/p2_source_status_v2.md)
- [Current harness instructions](epistemics_lab/README.md)
- [Preregistration draft](research/preregistration_draft.md) — not registered or frozen
- [Original novelty review](research/novelty_review.md) and [source ledger](research/sources.json)
- [Human review requirements](research/human_review_protocol.md)

Use `epistemics_lab/harness_v2.py`, not the archived revision 1 prototype. Revision 1 remains available in the original ZIP for comparison. Its uncapped HTTP runner was removed from the active package. Current mock runs are under `epistemics_lab/simulated/`, clearly separated from real-run paths.

## What the software has done

The revision-2 dataset contains 612 scheduled trials. The scripted development validation has 468 trials per policy: 324 P1 trials and 144 P2 trials. P2's count is 9 conditions × 8 development items × 2 truth states. The earlier 96 was 6 × 8 × 2, not 8 × 12. These scripted runs test software; they are not findings about language models. No held-out or live-model experiment has been executed.

The budget ledger reserves conservative cost before each call and records returned usage afterwards, under an atomic persistent cap shared across workers. Missing usage fails closed. Exhaustion halts the run. No API model, price card or spending amount has been selected, and the example configuration intentionally cannot run.

## Deliberately unfinished scientific work

The protocol itself is a design draft. Confirmatory execution is disabled. Real-model pilots, pressure manipulation checks, animal-welfare expertise, free-text grading validation, adequate substantive case coverage, effect/precision targets, multiplicity procedures and formal registration remain outstanding. Blinded grading packets and mechanical labels are not human validation. Reserved diagnostic families are not an untouched confirmatory corpus.

Reconsider the two-project portfolio only for a demonstrated flaw or a newly established research gap, not another persuasive description of a discarded idea.

Validation: 32 implementation tests and 11 independently authored checks passed. Both scripted runs contain 468 development trials. The full revision-2 package is epistemics_research_revision2.zip.
